#ifndef __VBE_H__
#define __VBE_H__

extern volatile UCHAR* lfb_base;
extern USHORT          lfb_pitch;
extern USHORT          lfb_xres;
extern USHORT          lfb_yres;
extern UCHAR           lfb_bpp;

#endif
