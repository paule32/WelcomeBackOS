#ifndef SHARED_PAGES_H
#define SHARED_PAGES_H

#include "os.h"

extern ULONG address_user;
ULONG getAddressUserProgram();


#endif
