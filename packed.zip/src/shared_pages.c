#include "shared_pages.h"

ULONG getAddressUserProgram()
{
    return address_user;
}
