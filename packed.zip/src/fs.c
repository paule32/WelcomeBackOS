#include "fs.h"

fs_node_t* fs_root = 0; // The root of the filesystem.

ULONG read_fs(fs_node_t* node, ULONG offset, ULONG size, unsigned char* buffer)
{
    if (node->read != 0)  // Has the node got a read callback?
        return node->read(node, offset, size, buffer);
    else
        return 0;
}

ULONG write_fs(fs_node_t* node, ULONG offset, ULONG size, unsigned char* buffer)
{
    if (node->write != 0) // Has the node got a write callback?
        return node->write(node, offset, size, buffer);
    else
        return 0;
}

void open_fs(fs_node_t* node, unsigned char read, unsigned char write) {
    (void)read; (void)write;
    if (node && node->open) {
        node->open(node);
    }
}

void close_fs(fs_node_t* node)
{
    if (node->close != 0) // Has the node got a close callback?
        return node->close(node);
}

struct dirent* readdir_fs(fs_node_t* node, ULONG index)
{
    // Is the node a directory, and does it have a callback?
    if ( ((node->flags&0x7) == FS_DIRECTORY) && (node->readdir != 0) )
        return node->readdir(node,index);
    else
        return 0;
}

fs_node_t* finddir_fs(fs_node_t* node, char* name)
{
    // Is the node a directory, and does it have a callback?
    if ( ((node->flags&0x7) == FS_DIRECTORY) && (node->finddir != 0) )
        return node->finddir(node,name);
    else
        return 0;
}
